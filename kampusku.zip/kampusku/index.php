<?php
// langsung redirect ke halaman tampil mahasiswa
header("Location: tampil_mahasiswa.php");
?>